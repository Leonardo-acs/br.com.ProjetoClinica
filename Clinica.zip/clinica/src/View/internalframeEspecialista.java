/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

/**
 *
 * @author leoac
 */
import java.sql.*;
import Conexões.Conexao;
import javax.swing.JOptionPane;

public class internalframeEspecialista extends javax.swing.JInternalFrame {

    Connection conexao = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    /**
     * Creates new form CadastroEspecialista
     *
     * @throws java.sql.SQLException
     */
    public internalframeEspecialista() throws SQLException {
        initComponents();
        conexao = Conexao.conector();
    }
    // funçao de pesquisar no banco de dados o usuario que foi digitado pelo id
    private void pesquisar() {
        String sql = "Select *from dados_paciente where id=?";
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, txtID.getText());
            rs = pst.executeQuery();
            if (rs.next()) {
                txtNome.setText(rs.getString(2));
                txtEmail.setText(rs.getString(3));
                txtNascimento.setText(rs.getString(4));
                txtCEP.setText(rs.getString(5));
                txtTelefone.setText(rs.getString(6));
                txtSenha.setText(rs.getString(7));
                comboBoxEspecialidade.setSelectedItem(rs.getString(8));

            } else {
                JOptionPane.showMessageDialog(null, "Usuário não cadastrado.");
                // abaixo limpa os campos
                txtNome.setText(null);
                txtEmail.setText(null);
                txtNascimento.setText(null);
                txtCEP.setText(null);
                txtTelefone.setText(null);
                txtSenha.setText(null);

            }
            //se tiver algum erro com o bd ira aparecer essa msg 
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    //adicionando os dados no bd 
    private void adicionar() {
        String sql = "insert into dados_paciente(id,nome,email,data_nascimento,cep,telefone,senha,perfil)values(?,?,?,?,?,?,?,?)";
        try {
            pst = conexao.prepareCall(sql);
            pst.setString(1, txtID.getText());
            pst.setString(2, txtNome.getText());
            pst.setString(3, txtEmail.getText());
            pst.setString(4, txtNascimento.getText());
            pst.setString(5, txtCEP.getText());
            pst.setString(6, txtTelefone.getText());
            pst.setString(7, txtSenha.getText());
            pst.setString(8, comboBoxEspecialidade.getSelectedItem().toString());
            //se algum dos campos estiver vazio exibir msg
            if ((txtID.getText().isEmpty()) || (txtNome.getText().isEmpty()) || (txtSenha.getText().isEmpty())||(txtCEP.getText().isEmpty())||(txtNascimento.getText().isEmpty())||(txtTelefone.getText().isEmpty())||(txtEmail.getText().isEmpty())) {
                JOptionPane.showMessageDialog(null, "Preencha todos os campos.");

            } else {
                
                int adicionado = pst.executeUpdate();//atualiza o bd
                //se o conteudo for maior q 0 msotra mensagem 
                if (adicionado > 0) {
                    JOptionPane.showMessageDialog(null, "Usuário cadastrado.");
                    // limpa os campos preenchidos
                    txtID.setText(null);
                    txtNome.setText(null);
                    txtEmail.setText(null);
                    txtNascimento.setText(null);
                    txtCEP.setText(null);
                    txtTelefone.setText(null);
                    txtSenha.setText(null);

                }
            }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);

        }
        

    }
// método alterar
    private void alterar(){
        String sql="Update dados_paciente set nome=?,email=?,data_nascimento=?,cep=?,telefone=?,senha=?,perfil=? where id=?";
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1,txtNome.getText());
            pst.setString(2,txtEmail.getText());
            pst.setString(3,txtNascimento.getText());
            pst.setString(4,txtCEP.getText());
            pst.setString(5,txtTelefone.getText());pst.setString(6,txtSenha.getText());
            pst.setString(7,comboBoxEspecialidade.getSelectedItem().toString());
            pst.setString(8,txtID.getText());
            if ((txtID.getText().isEmpty()) || (txtNome.getText().isEmpty()) || (txtSenha.getText().isEmpty())||(txtCEP.getText().isEmpty())||(txtNascimento.getText().isEmpty())||(txtTelefone.getText().isEmpty())||(txtEmail.getText().isEmpty())) {
                JOptionPane.showMessageDialog(null, "Preencha todos os campos.");

            } else {

                int adicionado = pst.executeUpdate();//atualiza o bd
                if (adicionado > 0) {
                    JOptionPane.showMessageDialog(null, "Dados Alterados Com Sucesso.");
                    // limpa os campos preenchidos
                    txtID.setText(null);
                    txtNome.setText(null);
                    txtEmail.setText(null);
                    txtNascimento.setText(null);
                    txtCEP.setText(null);
                    txtTelefone.setText(null);
                    txtSenha.setText(null);

                }
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        
    }
    private void deletar(){
        int confirma = JOptionPane.showConfirmDialog(null,"Tem certeza que deseja deletar esse usuário?","ATENÇÃO",JOptionPane.YES_NO_OPTION);
        if(confirma ==JOptionPane.YES_OPTION){
            String sql = "delete from dados_paciente where id=?";
            try {
                pst = conexao.prepareStatement(sql);
                pst.setString(1,txtID.getText());
                //pst.executeUpdate();
                int apagado =  pst.executeUpdate();
                if(apagado>0){
                    JOptionPane.showMessageDialog(null, "Usuário Apagado.");
                    txtID.setText(null);
                    txtNome.setText(null);
                    txtEmail.setText(null);
                    txtNascimento.setText(null);
                    txtCEP.setText(null);
                    txtTelefone.setText(null);
                    txtSenha.setText(null);
                    
                    
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblID = new javax.swing.JLabel();
        lblNome = new javax.swing.JLabel();
        lblEmail = new javax.swing.JLabel();
        lblNascimento = new javax.swing.JLabel();
        lblCEP = new javax.swing.JLabel();
        lblTelefone = new javax.swing.JLabel();
        lblSenha = new javax.swing.JLabel();
        labelEspecialidade = new javax.swing.JLabel();
        txtID = new javax.swing.JTextField();
        txtNome = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        txtNascimento = new javax.swing.JTextField();
        txtCEP = new javax.swing.JTextField();
        txtTelefone = new javax.swing.JTextField();
        txtSenha = new javax.swing.JTextField();
        buttoAdd = new javax.swing.JButton();
        buttonDeletar = new javax.swing.JButton();
        buttonPesquisar = new javax.swing.JButton();
        comboBoxEspecialidade = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        buttonAlterar = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setTitle("Cadastro");
        setToolTipText("");
        setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        setMaximumSize(new java.awt.Dimension(544, 337));
        setMinimumSize(new java.awt.Dimension(544, 337));
        setPreferredSize(new java.awt.Dimension(544, 337));

        lblID.setText("ID:");

        lblNome.setText("Nome:");

        lblEmail.setText("Email:");

        lblNascimento.setText("Nascimento:");

        lblCEP.setText("CEP:");

        lblTelefone.setText("Telefone:");

        lblSenha.setText("*Senha:");

        labelEspecialidade.setText("Especialidade:");

        txtID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIDActionPerformed(evt);
            }
        });

        txtNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeActionPerformed(evt);
            }
        });

        txtEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEmailActionPerformed(evt);
            }
        });

        txtNascimento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNascimentoActionPerformed(evt);
            }
        });

        txtCEP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCEPActionPerformed(evt);
            }
        });

        txtTelefone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelefoneActionPerformed(evt);
            }
        });

        txtSenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSenhaActionPerformed(evt);
            }
        });

        buttoAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/imagens/icons/iconfinder_file_add_48761.png"))); // NOI18N
        buttoAdd.setToolTipText("Adicionar");
        buttoAdd.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        buttoAdd.setPreferredSize(new java.awt.Dimension(64, 64));
        buttoAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttoAddActionPerformed(evt);
            }
        });

        buttonDeletar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/imagens/icons/iconfinder_file_delete_48762.png"))); // NOI18N
        buttonDeletar.setToolTipText("Deletar");
        buttonDeletar.setContentAreaFilled(false);
        buttonDeletar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        buttonDeletar.setPreferredSize(new java.awt.Dimension(64, 64));
        buttonDeletar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonDeletarActionPerformed(evt);
            }
        });

        buttonPesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/imagens/icons/iconfinder_file_search_48764.png"))); // NOI18N
        buttonPesquisar.setToolTipText("Pesquisar");
        buttonPesquisar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        buttonPesquisar.setPreferredSize(new java.awt.Dimension(64, 64));
        buttonPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonPesquisarActionPerformed(evt);
            }
        });

        comboBoxEspecialidade.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "admin", "Médico", "Paciente" }));
        comboBoxEspecialidade.setToolTipText("");

        jLabel1.setText("(ano/mês/dia)");

        buttonAlterar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/imagens/icons/iconfinder_document_text_edit_103514.png"))); // NOI18N
        buttonAlterar.setToolTipText("Alterar");
        buttonAlterar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        buttonAlterar.setPreferredSize(new java.awt.Dimension(64, 64));
        buttonAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonAlterarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblID, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblEmail)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(labelEspecialidade)
                        .addComponent(buttoAdd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblNascimento, javax.swing.GroupLayout.Alignment.LEADING))
                    .addComponent(lblNome, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(txtNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel1)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(comboBoxEspecialidade, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(lblSenha)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(49, 49, 49)
                                        .addComponent(buttonPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(37, 37, 37)
                                        .addComponent(buttonAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(48, 48, 48)
                                        .addComponent(buttonDeletar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(txtSenha, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(80, 80, 80))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblCEP)
                        .addGap(18, 18, 18)
                        .addComponent(txtCEP, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblTelefone)
                        .addGap(18, 18, 18)
                        .addComponent(txtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(84, 84, 84))))
        );

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {buttoAdd, buttonDeletar, buttonPesquisar});

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblID)
                    .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblCEP)
                    .addComponent(txtCEP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTelefone)
                    .addComponent(txtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNome)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEmail)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNascimento)
                    .addComponent(txtNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelEspecialidade)
                    .addComponent(lblSenha)
                    .addComponent(txtSenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboBoxEspecialidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(buttoAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buttonDeletar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buttonPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buttonAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(47, Short.MAX_VALUE))
        );

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {buttoAdd, buttonDeletar, buttonPesquisar});

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIDActionPerformed

    private void txtNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeActionPerformed

    private void txtEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEmailActionPerformed

    private void txtNascimentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNascimentoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNascimentoActionPerformed

    private void txtCEPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCEPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCEPActionPerformed

    private void txtTelefoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelefoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTelefoneActionPerformed

    private void txtSenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSenhaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSenhaActionPerformed

    private void buttoAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttoAddActionPerformed
        // adcionando
        adicionar();
    }//GEN-LAST:event_buttoAddActionPerformed

    private void buttonPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonPesquisarActionPerformed
        // chamndo o pesquisar
        pesquisar();
    }//GEN-LAST:event_buttonPesquisarActionPerformed

    private void buttonAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonAlterarActionPerformed
        // chamndo alterar
        alterar();
    }//GEN-LAST:event_buttonAlterarActionPerformed

    private void buttonDeletarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonDeletarActionPerformed
        // chamando o deletar
        deletar();
    }//GEN-LAST:event_buttonDeletarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buttoAdd;
    private javax.swing.JButton buttonAlterar;
    private javax.swing.JButton buttonDeletar;
    private javax.swing.JButton buttonPesquisar;
    private javax.swing.JComboBox<String> comboBoxEspecialidade;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel labelEspecialidade;
    private javax.swing.JLabel lblCEP;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblID;
    private javax.swing.JLabel lblNascimento;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblSenha;
    private javax.swing.JLabel lblTelefone;
    private javax.swing.JTextField txtCEP;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtID;
    private javax.swing.JTextField txtNascimento;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtSenha;
    private javax.swing.JTextField txtTelefone;
    // End of variables declaration//GEN-END:variables

}
