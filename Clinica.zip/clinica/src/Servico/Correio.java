/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servico;

import Model.Agendamento;

/**
 *
 * @author gosjr
 */
public class Correio {
    public void NotificarPorEmail(Agendamento agendamento){
        String emailFormatado = formarEmail(agendamento);
        String destinatario = agendamento.getPaciente().getEmail();
        Email email = new Email("Agendamento Clínica", emailFormatado, destinatario);
        email.enviar();
    }

    private String formarEmail(Agendamento agendamento) {
        String nomeCliente = agendamento.getPaciente().getNome();
        String servico = agendamento.getServico().getDescricao();
        String dataAgendamento = agendamento.getDataFormatada();
        String horaAgendamento = agendamento.getHoraFormatada();
        float valor = agendamento.getValor();
        return "Olá, "+nomeCliente +"! Seu agendamento para "+
                servico+" Está marcado para o dia "+dataAgendamento+
                " às "+ horaAgendamento + " Preço: "+valor+" Até logo!";
    }
}
