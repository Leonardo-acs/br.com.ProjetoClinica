/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Conexões;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author leoac
 */
public class Conexao {
    
    // estabelece a conexao com o bd
    public static Connection conector () throws SQLException{
        java.sql.Connection conexao = null;
        // chamando o driver
        String driver = "com.mysql.jdbc.Driver";
        //caminho para o banco com o nome do banco de dados
        String url = "jdbc:mysql://localhost:3307/dados_paciente";
        String user = "root";
        String password = "818-Jklpuzo07";
        
        try {
            //executa o arquivo do driver
            Class.forName(driver);
            conexao = DriverManager.getConnection(url, user, password);
            return conexao;
            
            
        } catch (Exception e) {
            
        }
        return null;
        }
    
        
        
        
    

    
}
